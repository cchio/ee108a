/////////////////////////////////////////////////////////////////////////
/// DISCLAIMER:                                                       ///
/// This patch DOES NOT affect your grade at all. You DO NOT have to  ///
/// apply this patch if you don't want to. If it causes anything to   ///
/// break, you can roll back the changes, ignore this patch, and turn ///
/// in a final project using the old ac97_if code                     ///
/////////////////////////////////////////////////////////////////////////

This patch should fix issues with audio sounding fuzzy and generally not good. The issue is very fundamental and nondeterministic, so it appears in projects randomly and regardless of whether you have chords/harmonics/dynamics implemented, or just pure tones.

To apply the patch, replace your project's ac97_if.ngc and ac97_if.v with the ones provided in this archive. Then, in your top-level module, replace the code instantiating ac97_if with this:
//---------------------------------------------------------------------------
    ac97_if codec(
        .ClkIn(clk),
        .Reset(reset), // Changed (new port)
        .PCM_Playback_Left(codec_sample),
        .PCM_Playback_Right(codec_sample),
        .PCM_Record_Left(),
        .PCM_Record_Right(),
        .PCM_Record_Valid(), // Changed (new port)
        .PCM_Playback_Accept(new_frame),  // Changed (used to be called New_Frame)
        .AC97Reset_n(AC97Reset_n),
        .AC97Clk(AC97Clk),
        .Sync(Sync),
        .SData_Out(SData_Out),
        .SData_In(SData_In),
        .Debug() // Changed (new port)
    );
//---------------------------------------------------------------------------
The only differences are one of the port names have changed and a few new (unused) ports have been added.

After doing all of this, restart ISE and resynthesize.
