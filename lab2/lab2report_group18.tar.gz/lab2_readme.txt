EE108a Lab 2 16 October 2012
----------------------------
Group 18.

Lab Members: Matthew Cooper
	     Dominic Delgado
	     Clarence Chio

This lab was fun.
